

module.exports = require('./dist/zoomus-websdk-embedded.umd.min');
